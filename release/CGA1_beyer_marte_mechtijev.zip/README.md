# Visual Computing Car
## Team
- Martin Johannes Beyer
- Nicolas Marte
- Islam Mechtijev

---

## Controls
- [W] - forward driving
- [A] - steer left
- [S] - backward driving
- [D] - steer right
- [LShift] - increase speed
- [1] - static camera
- [2] - following camera
- [Mouse drag] - change angle of camera
- [Mousewheel] - zoom in / out

---

