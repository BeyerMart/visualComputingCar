# Visual Computing Car

## Team
- Martin Johannes Beyer
- Nicolas Marte
- Islam Mechtijev
---
## Controls
- [W] - forward driving
- [A] - steer left
- [S] - backward driving
- [D] - steer right
- [8] - time of day (night)
- [9] - time of day (evening)
- [0] - time of day (day)
- [L] - toggle lights on / off